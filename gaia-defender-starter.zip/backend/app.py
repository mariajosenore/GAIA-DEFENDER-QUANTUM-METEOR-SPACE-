
from flask import Flask, request, jsonify
from flask_cors import CORS
import os, requests, math, datetime

app = Flask(__name__)
CORS(app)

NASA_API_KEY = os.getenv("NASA_API_KEY", "DEMO_KEY")  # Replace with your key in production

NEO_FEED_URL = "https://api.nasa.gov/neo/rest/v1/feed"

def tnt_megatons(joules: float) -> float:
    # 1 megaton TNT ≈ 4.184e15 J
    return joules / 4.184e15

@app.get("/api/neo")
def neo_feed():
    # Default to today's date in UTC
    start_date = request.args.get("start_date")
    if not start_date:
        start_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")

    params = {
        "start_date": start_date,
        "end_date": start_date,
        "api_key": NASA_API_KEY
    }
    try:
        r = requests.get(NEO_FEED_URL, params=params, timeout=15)
        r.raise_for_status()
        data = r.json()
        return jsonify({"ok": True, "data": data})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.get("/api/impact-energy")
def impact_energy():
    try:
        diameter_m = float(request.args.get("diameter_m", 140))  # 140 m threshold asteroid
        density = float(request.args.get("density", 3000))       # kg/m^3 (rocky asteroid)
        velocity_km_s = float(request.args.get("velocity_km_s", 20))  # km/s typical NEO

        radius_m = diameter_m / 2.0
        volume_m3 = (4.0/3.0) * math.pi * (radius_m ** 3)
        mass_kg = density * volume_m3
        v_m_s = velocity_km_s * 1000.0

        kinetic_energy_j = 0.5 * mass_kg * (v_m_s ** 2)
        tnt_mt = tnt_megatons(kinetic_energy_j)

        return jsonify({
            "ok": True,
            "inputs": {
                "diameter_m": diameter_m,
                "density_kg_m3": density,
                "velocity_km_s": velocity_km_s
            },
            "results": {
                "mass_kg": mass_kg,
                "kinetic_energy_j": kinetic_energy_j,
                "tnt_megatons": tnt_mt
            }
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "gaia-defender-backend"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)
