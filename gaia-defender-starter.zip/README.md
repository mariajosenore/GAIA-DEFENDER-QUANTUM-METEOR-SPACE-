
# GAIA DEFENDER: EarthLink Intelligence Network

**NASA Space Apps Challenge 2025 – Meteor Madness**  
Team: **Quantum Meteor Space** (Colombia)

This is a minimal, GitHub-ready demo repo that shows how to:
- Fetch **NASA NEO** data
- Do a simple **impact energy** estimate (TNT equivalent)
- Render an interactive **3D Earth** with an asteroid marker using **Three.js**
- Keep the code small, readable, and easy to run during a hackathon

> **Data Sources:** NASA NEO API, USGS Earthquake & Elevation datasets (links in README).  
> **Note:** Replace the placeholder API key with your own NASA API key.


## 🌐 Live Demo (Local)
```bash
# 1) Backend
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
# set your NASA key (Linux/Mac)
export NASA_API_KEY=DEMO_KEY
# Windows PowerShell:
# $Env:NASA_API_KEY = "DEMO_KEY"
flask --app app.py run --port 5001

# 2) Frontend (just open index.html)
cd ../frontend
# Open index.html in your browser (double click or use Live Server)
```

## ⚙️ Backend Endpoints

- `GET /api/neo?start_date=YYYY-MM-DD`  
  Proxies NASA NEO feed for a given day (default: today).

- `GET /api/impact-energy?diameter_m=140&density=3000&velocity_km_s=20`  
  Returns simple physics estimates: mass, kinetic energy (J), TNT equivalent (MT).

> **DISCLAIMER:** Physics simplified for demo purposes. Use proper models for research/critical decisions.


## 🛰️ Data Sources
- NASA NEO API: https://api.nasa.gov/ (Asteroids - NeoWs)
- USGS Earthquake Catalog: https://earthquake.usgs.gov/fdsnws/event/1/
- USGS Elevation (The National Map): https://apps.nationalmap.gov/ (DEM/3DEP)

## 🧠 AI Disclosure
- Some illustrative images or text may be **AI-assisted** (marked as such). No NASA logos were used in AI-generated media.

## 📄 License
MIT (see LICENSE)
