
const diameter = document.getElementById('diameter');
const velocity = document.getElementById('velocity');
const density  = document.getElementById('density');
const diameterVal = document.getElementById('diameterVal');
const velocityVal = document.getElementById('velocityVal');
const densityVal  = document.getElementById('densityVal');
const impactOut = document.getElementById('impactOut');
const neoOut    = document.getElementById('neoOut');
const calcBtn   = document.getElementById('calcBtn');

const BACKEND = (location.hostname === 'localhost' || location.hostname === '127.0.0.1')
  ? 'http://localhost:5001'
  : 'http://localhost:5001'; // adjust if deploying elsewhere

// UI bindings
[diameter, velocity, density].forEach(input => {
  input.addEventListener('input', () => {
    diameterVal.textContent = diameter.value;
    velocityVal.textContent = velocity.value;
    densityVal.textContent  = density.value;
  });
});

calcBtn.addEventListener('click', async () => {
  const url = new URL(BACKEND + '/api/impact-energy');
  url.searchParams.set('diameter_m', diameter.value);
  url.searchParams.set('density', density.value);
  url.searchParams.set('velocity_km_s', velocity.value);
  const res = await fetch(url);
  const json = await res.json();
  impactOut.textContent = JSON.stringify(json, null, 2);
});

async function fetchNEO(){
  const url = new URL(BACKEND + '/api/neo');
  const res = await fetch(url);
  const json = await res.json();
  if(json.ok){
    // Show a tiny summary for today
    const neo = json.data.near_earth_objects;
    const key = Object.keys(neo)[0];
    const items = neo[key] || [];
    const summary = items.map(o => ({
      name: o.name,
      est_diameter_m: o.estimated_diameter?.meters?.estimated_diameter_max?.toFixed(1),
      rel_velocity_km_s: parseFloat(o.close_approach_data?.[0]?.relative_velocity?.kilometers_per_second || 0).toFixed(2),
      miss_distance_km: parseFloat(o.close_approach_data?.[0]?.miss_distance?.kilometers || 0).toFixed(0)
    }));
    neoOut.textContent = JSON.stringify(summary.slice(0,5), null, 2);
    if(summary.length>0){
      updateAsteroidMarker(parseFloat(summary[0].rel_velocity_km_s));
    }
  } else {
    neoOut.textContent = 'NEO fetch error: ' + json.error;
  }
}

// THREE.js minimal Earth + asteroid marker
let scene, camera, renderer, earth, asteroid;
initScene();
animate();
fetchNEO(); // initial

function initScene(){
  const canvas = document.getElementById('scene');
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(60, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
  camera.position.set(0,0,3.2);

  renderer = new THREE.WebGLRenderer({canvas, antialias:true});
  resize();
  window.addEventListener('resize', resize);

  // Earth sphere
  const geo = new THREE.SphereGeometry(1, 64, 64);
  const mat = new THREE.MeshStandardMaterial({color: 0x1f5fff, roughness: 0.6, metalness: 0.1});
  earth = new THREE.Mesh(geo, mat);
  scene.add(earth);

  // Lights
  const hemi = new THREE.HemisphereLight(0xffffff, 0x222244, 1.2);
  scene.add(hemi);
  const dir = new THREE.DirectionalLight(0xffffff, 0.6);
  dir.position.set(3,2,4);
  scene.add(dir);

  // Asteroid marker (small sphere)
  const aGeo = new THREE.SphereGeometry(0.05, 16, 16);
  const aMat = new THREE.MeshStandardMaterial({color: 0xffaa00, emissive: 0x332200});
  asteroid = new THREE.Mesh(aGeo, aMat);
  asteroid.position.set(1.8, 0.2, 0);
  scene.add(asteroid);
}

function updateAsteroidMarker(speed_km_s){
  // Simple: move asteroid a bit based on speed to show change (purely illustrative)
  const t = Date.now() * 0.001;
  asteroid.position.x = 1.8 * Math.cos(t * 0.2 + speed_km_s*0.01);
  asteroid.position.y = 1.0 * Math.sin(t * 0.2 + speed_km_s*0.01);
}

function animate(){
  requestAnimationFrame(animate);
  earth.rotation.y += 0.0008;
  updateAsteroidMarker(20);
  renderer.render(scene, camera);
}

function resize(){
  const canvas = renderer.domElement;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w/h;
  camera.updateProjectionMatrix();
}
